﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace kajal_lakhani_PracticalTask.Models
{
    public class UserModel
    {
        private string _password;

        private string _username;

        public string username
        {
            get { return _username; }
            set { _username = value; }
        }
        public string password
        {
            get { return _password; }
            set { _password = value; }
        }
    }
}