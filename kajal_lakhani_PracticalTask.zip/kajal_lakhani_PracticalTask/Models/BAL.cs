﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace kajal_lakhani_PracticalTask.Models
{
    public class BAL
    {
        DAL objdal = new DAL();
       
        public DataSet UserLogin(UserModel objLogin)
        {
           

                return objdal.LoginCredential(objLogin);
           
        }

        public DataSet AllNotes(int id)
        {
          return objdal.Notesdateils(id);
           
        }

        public int deleteisernotes(int notesid)
        {
            int i= objdal.deletenotes(notesid);
            return i;

        }
        public int  insertusernotes(NotesModel notesdata)
        {
            int i = objdal.insertnotes(notesdata);
            return i;

        }
    }
}