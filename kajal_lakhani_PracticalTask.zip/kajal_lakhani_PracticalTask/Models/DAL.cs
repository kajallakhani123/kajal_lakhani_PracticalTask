﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace kajal_lakhani_PracticalTask.Models
{
    public class DAL
    {

        connection cn = new connection();
        public DataSet LoginCredential(UserModel login)
        {
          
            SqlConnection con = cn.sql_connection();
           
            SqlCommand cmd = new SqlCommand("userlogin", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@username", login.username);
            cmd.Parameters.AddWithValue("@password", login.password);
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds;

        }

        public DataSet Notesdateils(int id)
        {

            SqlConnection con = cn.sql_connection();

            SqlCommand cmd = new SqlCommand("create_user_notes", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userid", id);
            cmd.Parameters.AddWithValue("@Action", "Select");
            SqlDataAdapter da = new SqlDataAdapter();
            DataSet ds = new DataSet();
            da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            return ds;

        }

        public int deletenotes(int notesid)
        {
            try
            {

                SqlConnection con = cn.sql_connection();
                SqlCommand cmd = new SqlCommand("dbo.create_user_notes", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@notesid", notesid);
                cmd.Parameters.AddWithValue("@Action", "Delete"); 
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                return i;


            }
            catch (Exception ex)
            {
                return 0;
            }

        }
        public int insertnotes(NotesModel notesdata)
        {
            try
            {

                SqlConnection con = cn.sql_connection();
                SqlCommand cmd = new SqlCommand("dbo.create_user_notes", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userid", notesdata.userid);
                cmd.Parameters.AddWithValue("@title", notesdata.title);
                cmd.Parameters.AddWithValue("@notes", notesdata.notes);
                cmd.Parameters.AddWithValue("@Action", "Insert");
                con.Open();
                int i = cmd.ExecuteNonQuery();
                con.Close();
                return i;


            }
            catch (Exception ex)
            {
                return 0;
            }

        }
    }
}
