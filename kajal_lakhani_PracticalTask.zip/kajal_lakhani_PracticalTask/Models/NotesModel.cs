﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace kajal_lakhani_PracticalTask.Models
{
    public class NotesModel
    {

        private string _title;

        private string _notes;
        private int _userid;

        public string title
        {
            get { return _title; }
            set { _title = value; }
        }
        public string notes
        {
            get { return _notes; }
            set { _notes = value; }
        }

        public int userid
        {
            get { return _userid; }
            set { _userid = value; }
        }
    }
}