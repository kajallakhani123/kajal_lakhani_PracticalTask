﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;

namespace kajal_lakhani_PracticalTask.Models
{
    public class connection
    {
        public SqlConnection sql_connection()
        {
            string constring = ConfigurationManager.ConnectionStrings["conn"].ToString();
            SqlConnection con  = new SqlConnection(constring);
            return con;
        }
    }
}