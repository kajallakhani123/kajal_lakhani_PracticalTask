﻿using kajal_lakhani_PracticalTask.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace kajal_lakhani_PracticalTask
{
    public partial class usernotes : System.Web.UI.Page
    {
        BAL objnotesBL = new BAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["uid"]==null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                bindnotes();
            }
        }

        protected void bindnotes()
        {
           
           
           
            try
            {
                DataSet ds = new DataSet();
                ds = objnotesBL.AllNotes(Convert.ToInt32(Session["uid"]));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    rpt_notes.DataSource = ds.Tables[0];
                    rpt_notes.DataBind();

                }
                else
                {
                    rpt_notes.DataSource = null;
                    rpt_notes.DataBind();
                  
                }
               
            }
            catch (Exception ex)
            {
                lblmsg.Text = "Someting went Wrong";
            }
        }

        protected void lnk_delete_Click(object sender, EventArgs e)
        {
            try
            {
                LinkButton lnk = (LinkButton)(sender);
                int i = objnotesBL.deleteisernotes(Convert.ToInt32(lnk.CommandArgument));
                if(i!=0)
                {
                    lblmsg.Text = "Delete Successfully!";
                    bindnotes();
                }
                else
                {
                    lblmsg.Text = "Someting went Wrong Try again";
                }
            }
            catch
            {
                lblmsg.Text= "Someting went Wrong Try again";
            }
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                NotesModel obJNotes = new NotesModel();
                obJNotes.title = txt_title.Text.Trim();
                obJNotes.notes = txt_notes.Text.Trim();
                obJNotes.userid = Convert.ToInt32(Session["uid"]);
                int i = objnotesBL.insertusernotes(obJNotes);
                if (i != 0)
                {
                    lblmsgnotes.Text = "Insert Successfully!";
                    txt_notes.Text = string.Empty;
                    txt_title.Text = string.Empty;
                    bindnotes();
                }
                else
                {
                    lblmsgnotes.Text = "Someting went Wrong Try again";
                }
            }
            catch
            {
                lblmsgnotes.Text = "Someting went Wrong Try again";
            }
        }

        protected void lnk_logout_Click(object sender, EventArgs e)
        {
            Session["uid"] = null;
            Response.Redirect("Login.aspx");
        }
    }
}