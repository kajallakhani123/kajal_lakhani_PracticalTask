﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using kajal_lakhani_PracticalTask.Models;

namespace kajal_lakhani_PracticalTask
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                Session["uid"] = null;
                lblmsg.Text = "";
            }
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            BAL objloginBL = new BAL();
            UserModel obJlogin = new UserModel();
            obJlogin.username = txt_username.Text.Trim();
            obJlogin.password = txt_password.Text.Trim();
            try
            {
                DataSet ds = new DataSet();
                ds = objloginBL.UserLogin(obJlogin);
                if(ds.Tables[0].Rows.Count>0)
                {

               
                Session["uid"] = ds.Tables[0].Rows[0]["user_id"];
                Response.Redirect("usernotes.aspx");
                }
                else
                {
                    lblmsg.Text = "Invalid Username or Password";
                }
            }
            catch(Exception ex)
            {
                lblmsg.Text = "Someting went Wrong Try again";
            }

            }
        }
    }
  